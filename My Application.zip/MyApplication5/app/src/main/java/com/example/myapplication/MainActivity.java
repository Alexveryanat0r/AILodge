package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.graphics.Matrix;
import android.widget.TextView;
import android.widget.Toast;

import android.view.ScaleGestureDetector;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private ScaleGestureDetector detector;
    private boolean ISPrevScale = false;

    Matrix matrix;
    float scale = 1f;
    float minScale = 1f;
    float maxScale = 3f;
    float prevX, prevY;
    float prevDistance = 0, curDistance;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.imageView2);
        detector = new ScaleGestureDetector(this, new ScaleListener());

        imageView = findViewById(R.id.imageView2);


        matrix = new Matrix();

//        imageView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                if(event.getPointerCount() == 2)
//                {
//                    TextView Text = findViewById(R.id.textView);
//                    Text.setText(event.toString());
//                    detector.onTouchEvent(event);
//
//                return true;}
//                switch (event.getAction() & MotionEvent.ACTION_MASK) {
//                    case MotionEvent.ACTION_DOWN:
//                        prevX = event.getX();
//                        prevY = event.getY();
//                        break;
//                    case MotionEvent.ACTION_MOVE:
//                        float newX = event.getX();
//                        float newY = event.getY();
//                        float deltaX = newX - prevX;
//                        float deltaY = newY - prevY;
//
//                        matrix.postTranslate(deltaX, deltaY);
//                        imageView.setImageMatrix(matrix);
//
//                        prevX = newX;
//                        prevY = newY;
//                        break;
//                    case MotionEvent.ACTION_POINTER_DOWN:
//                        float dist = getDistance(event);
//                        if (dist > 10f) {
//                            float centerX = (event.getX(0) + event.getX(1)) / 2;
//                            float centerY = (event.getY(0) + event.getY(1)) / 2;
//
//                            switch (event.getAction() & MotionEvent.ACTION_MASK) {
//                                case MotionEvent.ACTION_POINTER_DOWN:
//                                    scale = getScale();
//                                    break;
//                                case MotionEvent.ACTION_MOVE:
//                                    float newDist = getDistance(event);
//                                    if (newDist > 10f) {
//                                        scale = scale * (newDist / dist);
//                                        scale = Math.max(minScale, Math.min(scale, maxScale));
//
//                                        matrix.setScale(scale, scale, centerX, centerY);
//                                        imageView.setImageMatrix(matrix);
//                                    }
//                                    break;
//                            }
//                        }
//                        break;
//                }
//                return true;
//            }
//        });



//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (scale == 1f) {
//                    // If the scale is 1, increase the scale to the specified value
//                    scale = 2f;
//                } else {
//                    // If the scale is not 1, reset the scale to 1
//                    scale = 1f;
//                }
//
//                matrix.setScale(scale, scale);
//                imageView.setImageMatrix(matrix);
//            }
//        });


    }

    private float getDistance(MotionEvent event) {
        int dx = (int) (event.getX(0) - event.getX(1));
        int dy = (int) (event.getY(0) - event.getY(1));
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private float getScale() {
        float[] values = new float[9];
        matrix.getValues(values);
        return values[Matrix.MSCALE_X];
    }

    public boolean onTouchEvent(MotionEvent event) {
        // Перенаправляем события касания в класс ScaleListener
//        detector.onTouchEvent(event);
//        return super.onTouchEvent(event);

        if(event.getPointerCount() == 2)
        {
            TextView Text = findViewById(R.id.textView);
            Text.setText(event.toString());
            detector.onTouchEvent(event);

            ISPrevScale = true;
            return true;
        }

        if(ISPrevScale)
        {
            prevX = event.getX();
            prevY = event.getY();

            ISPrevScale = false;
        }


        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                prevX = event.getX();
                prevY = event.getY();
                break;

            case MotionEvent.ACTION_MOVE:
                TextView Text = findViewById(R.id.textView);
                Text.setText("Палец");

                float newX = event.getX();
                float newY = event.getY();
                float deltaX = newX - prevX;
                float deltaY = newY - prevY;

                matrix.postTranslate(deltaX, deltaY);
                imageView.setImageMatrix(matrix);

                prevX = newX;
                prevY = newY;
                break;
//            case MotionEvent.ACTION_POINTER_DOWN:
////                float dist = getDistance(event);
////                if (dist > 10f) {
////                    float centerX = (event.getX(0) + event.getX(1)) / 2;
////                    float centerY = (event.getY(0) + event.getY(1)) / 2;
////
////                    switch (event.getAction() & MotionEvent.ACTION_MASK) {
////                        case MotionEvent.ACTION_POINTER_DOWN:
////                            scale = getScale();
////                            break;
////                        case MotionEvent.ACTION_MOVE:
////                            float newDist = getDistance(event);
////                            if (newDist > 10f) {
////                                scale = scale * (newDist / dist);
////                                scale = Math.max(minScale, Math.min(scale, maxScale));
////
////                                matrix.setScale(scale, scale, centerX, centerY);
////                                imageView.setImageMatrix(matrix);
////                            }
////                            break;
////                    }
////                }
////                break;
        }
        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        float onScaleBegin = 0;
        float onScaleEnd = 0;

        @Override
        public boolean onScale(ScaleGestureDetector detector) {

            scale *= detector.getScaleFactor();
            imageView.setScaleX(scale);
            imageView.setScaleY(scale);

            return true;
        }
    }
}



